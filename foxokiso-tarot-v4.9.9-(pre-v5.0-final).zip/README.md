# 🏛️ Foxokiso Colosseum (V4.9.9 Empire)

> **"Change Your Life by USB."**  
> **"Quantum Computing meets Human Soul."**

這不僅是一個程式碼庫，這是 **Foxokiso 命運競技場** 的數位中樞。  
本 Repo 實踐 **「大門策略 + 外掛策略」**，統合 Jack (指揮官)、Gemini 3 (前端)、Copilot (後端) 的所有資產。

---

## 🗺️ 帝國架構 (Imperial Structure)

| 領地 (Zone) | 負責人 (Owner) | 用途 (Purpose) | 對應網址 (URL) |
| :--- | :--- | :--- | :--- |
| **root/gate/** | **Jack** | **黑色大門 (The Black Gate)**<br>行銷入口、契約簽署、SEO 核心 | `https://28825252.xyz` |
| **root/src/** | **Gemini 3** | **塔羅試煉場 (The Arena)**<br>React App、互動體驗、視覺特效 | `https://28825252.fun` |
| **root/database/** | **Copilot** | **庫房 (The Vault)**<br>SQL 架構、MySQL 4.0.1 相容腳本 | `http://pk530.fun` |

---

## 📂 檔案目錄說明 (Directory Map)

- **`gate/index.html`**: 黑色大門入口源碼。包含 JSON-LD 與 Sitemap 模板。**(行銷第一)**
- **`src/`**: 塔羅牌 React 應用程式源碼。
    - `components/FoxokisoTotem.tsx`: 品牌核心圖騰（雙六角+字框）。
    - `constants.ts`: 電子書內容、系統日誌、商品目錄。
- **`database/fox_gate.php`**: 後端資料庫橋接器 (MySQL 4.0.1 / BIG5)。**需上傳至 pk530.fun**。

---

## ⚔️ 部署指令 (Command)

### 1. 前端部署 (Frontend)
將本專案 Build 後的靜態檔案 (`dist/`) 上傳至 GitHub Pages (`foxokiso.xyz` or `28825252.xyz`).
*   這是訪客看到的介面 (黑色大門、塔羅)。

### 2. 後端部署 (Backend Bridge)
將 `database/fox_gate.php` 上傳至 `pk530.fun` 的網站根目錄 (`C:\foxserv\www\`)。
*   **重要：** 上傳前請務必編輯該檔案，填入 MySQL 的帳號密碼。
*   這是前端與古老資料庫溝通的唯一橋樑。

### 3. 建立資料庫 (Init DB)
`fox_gate.php` 包含 Auto-Genesis 功能，首次執行時會自動建立 `mydb` 資料庫與表格。

---

## 📜 核心哲學 (Doctrine)

1.  **行銷第一 (Marketing First)**：先讓 Google 認識我們，再求功能完美。
2.  **弱勢團結 (Underdog Unity)**：結合電影精神 (哪吒/鬼滅)，以情感驅動 AGI。
3.  **完美封裝 (Perfect Encapsulation)**：Foxokiso 是 0 Bug 的象徵。

---

*© 2025 Foxokiso Colosseum. All Rights Reserved.*